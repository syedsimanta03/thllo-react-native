export default {
  green: '#24A5B0',
  deepgreen: '#20959e',
  darkgreen: '#175C63',
  alloorange: '#fd7833',
}
