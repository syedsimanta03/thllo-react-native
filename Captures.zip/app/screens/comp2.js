import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import styles from '../styles/SingleActivityStyle.js';
 
const comp2 = ({navigation}) => {
  return (
    <View style={styles.container}>
      <Text>comp2</Text>
    </View>
  );
};
 
export default comp2;