import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import styles from "../styles/ProfileStyle.js";

const ProfileScreen = () => {
  return (
    <View style={styles.container}>
      <Text>ProfileScreen</Text>
    </View>
  )
};

export default ProfileScreen;
