import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import styles from '../styles/SingleActivityStyle.js';
 
const SingleActivityScreen = ({navigation}) => {
  return (
    <View style={styles.container}>
      <Text>Activity</Text>
    </View>
  );
};
 
export default SingleActivityScreen;