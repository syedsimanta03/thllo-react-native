import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import styles from '../styles/SingleActivityStyle.js';
 
const comp1 = ({navigation}) => {
  return (
    <View style={styles.container}>
      <Text>comp1</Text>
    </View>
  );
};
 
export default comp1;