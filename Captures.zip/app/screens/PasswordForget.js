import React from 'react';
import { View, Text, Button, StyleSheet } from 'react-native';
import styles from '../styles/PasswordForgetStyle.js';
 
const PasswordForgetScreen = () => {
  return (
    <View style={styles.container}>
      <Text>Password Forget Screen</Text>
    </View>
  );
};
 
export default PasswordForgetScreen;