import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import styles from "../styles/GamesStyle.js";

const GamesScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text>GamesScreen</Text>
      {/*<Button title="" onPress={() => navigation.navigate("SingleGame")} />*/}
    </View>
  )
};

export default GamesScreen;
