import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import styles from "../styles/ActivitiesStyle.js";

const ActivitiesScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text>ActivitiesScreen</Text>

      {/*<Button
        title="Single activity" 
        onPress={() => navigation.navigate("SingleActivity")}
        visibility={0}
      />*/}
    </View>
  )
};

export default ActivitiesScreen;
