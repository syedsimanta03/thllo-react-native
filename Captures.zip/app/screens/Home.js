import React, { useEffect, useState } from 'react'
import GestureRecognizer, { swipeDirections } from 'react-native-swipe-gestures'
import ArticlesScreen from './Articles'
import { ScrollView, View, Text, Button, StyleSheet, Image } from 'react-native'
import styles from '../styles/HomeStyle.js'

const HomeScreen = ({ navigation }) => {
  const [titleData, setTitleData] = useState([])
  const [state, setState] = useState('')


  onSwipe = (gestureState) => {
    const { SWIPE_LEFT, SWIPE_RIGHT } = swipeDirections
    
    switch (gestureState) {
      case SWIPE_LEFT:
        navigation.navigate(state)
        break
      case SWIPE_RIGHT:
        navigation.navigate(state)
        break
    }
  }

  onSwipeRight = () => {
    setState('')
  }

  onSwipeLeft = (state) => {
    setState('ArticlesScreen')
    navigation.navigate(state)
  }

  useEffect(() => {
    fetch(
      'https://app.allo.care/php/api/simpleselect.php?s=strings^id-title-gr-en^title=|pagetitle|^id-asc^100'
    )
      .then((response) => response.json())
      .then((json) => setTitleData(json.data[0]))
      .catch((error) => console.error(error))
  }, [])

  var titleDatal
  if (global.lang === 'gr') {
    titleDatal = titleData.gr
  } else {
    titleDatal = titleData.en
  }
  
     const config = {
       velocityThreshold: 0.3,
       directionalOffsetThreshold: 80,
     }

  return (
    <>
      <GestureRecognizer
        onSwipe={(state) => onSwipe( state)}
        onSwipeLeft={(state) => onSwipeLeft(state)}
        onSwipeRight={(state) => onSwipeRight(state)}
        config={config}
        style={{
          flex: 1,
        }}
      >
        <ScrollView style={styles.scrollview}>
          <View style={styles.container}>
            {global.lang === 'gr' ? (
              <Text>{titleData.gr}</Text>
            ) : (
              <Text>{titleData.en}</Text>
            )}
            <Image
              source={{
                uri: 'https://app.allo.care/images/' + global.imgpart2,
              }}
              style={{ width: 200, height: 200 }}
            />
            <Text>{state}</Text>
          </View>
        </ScrollView>
      </GestureRecognizer>
    </>
  )
}

export default HomeScreen
