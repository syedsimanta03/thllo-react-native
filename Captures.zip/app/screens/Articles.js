import React from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import styles from "../styles/ArticlesStyle.js";

const ArticlesScreen = ({ navigation }) => {
  return (
    <View style={styles.container}>
      <Text>ArticlesScreenX</Text>
      {/*<Button title="Single article" onPress={() => navigation.navigate("SingleArticle")} />*/}
    </View>
  )
};

export default ArticlesScreen;
